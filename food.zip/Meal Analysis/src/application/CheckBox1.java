package application;

import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class CheckBox1 extends Application{
	
	@Override
	public void start(Stage stage) {
		VBox root = new VBox();
		Scene scene = new Scene(root,100,200);
		root.setSpacing(10);
		root.setPadding(new Insets(15,20,10,10));
		
		CheckBox checkBox = new CheckBox();
		
		root.getChildren().add(checkBox);
		
		stage.setScene(scene);
		stage.show();
	}

}
